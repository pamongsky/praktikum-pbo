public abstract class BangunDatar {
    public abstract double hitungKeliling();
}