/* Nama File : Poligon.java */
/* Nama / NIM : Muhammad Anshar Al Faruq / 24060122140148 */

package org.poligon;

public class Poligon {
    protected int jumlahSisi;

    public int getJumlahSisi(){
        return this.jumlahSisi;
    }
}
