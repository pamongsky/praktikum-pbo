public interface IFlyer {
    void fly();
}
