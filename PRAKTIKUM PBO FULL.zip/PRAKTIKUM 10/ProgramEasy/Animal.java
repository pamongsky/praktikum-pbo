public abstract class Animal {
    abstract void eat();
}
