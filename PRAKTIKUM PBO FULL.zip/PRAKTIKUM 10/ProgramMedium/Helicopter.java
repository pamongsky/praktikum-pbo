public class Helicopter {
    @Override
    public String toString() {
        return "Helicopter hanya memerlukan landasan kecil";
    }
}
