public class Truck {
    @Override
    public String toString() {
        return "Truck adalah angkutan darat yang sangat handal";
    }
}
