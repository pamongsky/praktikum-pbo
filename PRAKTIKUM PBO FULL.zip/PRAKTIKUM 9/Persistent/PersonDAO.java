public interface PersonDAO{
    public void savePerson(Person p) throws Exception;
}