-- Active: 1715767885615@@localhost@3306@pbo
SELECT * FROM person;