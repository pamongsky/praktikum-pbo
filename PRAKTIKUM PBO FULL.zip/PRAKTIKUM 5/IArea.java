/* Nama File : IArea.java */
/* Deskripsi : interface yang mendefinisikan kontrak bahwa setiap kelas yang membuat
               bahwa setiap kelas yang membuat implementasi dari interface ini harus memiliki cara untuk menghitung luas */
/* Nama / NIM : Muhammad Anshar Al Faruq / 24060122140148 */


public interface IArea {
    public double hitungLuas();
}