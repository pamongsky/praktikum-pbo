/* Nama File : BujurSangkar.java */
/* Deskripsi : Kelas yang membuat implementasi metode abstrak */
/* Nama / NIM : Muhammad Anshar Al Faruq / 24060122140148 */


public class BujurSangkar extends BangunDatar{
    public double hitungLuas(double sisi){
        luas = sisi*sisi;
        return luas;
    }
    
}