public class Bunyi {
    private String suara;

    public Bunyi() {
        this.suara = "";
    }

    public Bunyi(String suara) {
        this.suara = suara;
    }

    public String getSuara() {
        return suara;
    }

    public void setSuara(String suara) {
        this.suara = suara;
    }
}