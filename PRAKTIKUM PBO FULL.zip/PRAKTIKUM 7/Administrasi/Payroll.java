public class Payroll {
    public void cetakGaji(Pegawai pegawai) {
        pegawai.tampilData();
        System.out.println("------------------------");
    }
}