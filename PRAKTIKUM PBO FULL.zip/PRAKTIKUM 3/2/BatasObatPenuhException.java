/* File : BatasObatPenuhException.java */
/* Deskripsi : Program untuk menunjukkan Exception */
/* Nama/Nim : Muhammad Anshar Al Faruq /24060122140148 */

package tugas2;
public class BatasObatPenuhException extends Exception {
    public BatasObatPenuhException(String message) {
        super(message);
    }
}
